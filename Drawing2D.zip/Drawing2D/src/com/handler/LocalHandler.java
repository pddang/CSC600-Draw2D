package com.handler;
import com.data.*;
import com.main.Main;
import java.io.*;
import java.util.List;

public class LocalHandler {

    public static boolean saveDrawingToFile(File drawingFile)
    {
        try (ObjectOutputStream objOutputStream = new ObjectOutputStream(new FileOutputStream(drawingFile)))
        {
            PaneData paneData = new PaneData(Main.DrawingPane.getWidth(), Main.DrawingPane.getHeight(),Main.DrawingPane.getName());
            objOutputStream.writeObject(paneData);

            List<ObjectData> drawingObjList = DataHandler.getObjectDataList();
            for (ObjectData drawingObj : drawingObjList)
            {
                objOutputStream.writeObject(drawingObj);
            }
            return true;
        }

        catch (IOException ex)
        {
            System.out.printf("Unable to load the file: %s\n", drawingFile.getPath());
            System.out.printf("%s\n", ex.getMessage());
            return false;
        }
    }

    public static boolean loadDrawingFromFile(File fileName){
        FileInputStream file = null;
        ObjectInputStream object = null;
        PaneData paneData = null;
        Main.DrawingPane.getChildren().clear();
        try {
            file = new FileInputStream(fileName);
            object = new ObjectInputStream(file);
            Object myObject = object.readObject();
            System.out.println("Read object successfully");
            while(true) {
                if(myObject instanceof PaneData ){
                    paneData = (PaneData) myObject;
                    Main.DrawingPane.setPrefSize(paneData.getWidth(), paneData.getHeight());
                    Main.DrawingPane.resize(paneData.getWidth(), paneData.getHeight());
                    Main.DrawingPane.setName(paneData.getDrawingName());
                    Main.DrawingPane.setModified(false);
                    continue;
                }
                if (myObject instanceof CircleData) {
                    CircleData circleData = (CircleData) myObject;
                    Main.DrawingPane.getChildren().add(NewData.NewCircle(circleData));

                }
                if (myObject instanceof RectangleData) {
                    RectangleData rectangleData = (RectangleData) myObject;
                    Main.DrawingPane.getChildren().add(NewData.NewRectangle(rectangleData));
                }

            }
        } catch (EOFException ex){

            System.out.println("End of file.");

        } catch (ClassNotFoundException  | IOException  ex){
            System.out.printf("Unable to load drawing from file: %s\n", fileName.getPath());
            System.out.printf("%s\n", ex.getMessage());
            return false;
        }
        finally {
            if( file != null){
                try{
                    file.close();
                } catch (IOException ex){
                    ex.printStackTrace();
                }
            }
            if(object !=  null ){
                try {
                    object.close();
                } catch (IOException ex){
                    ex.printStackTrace();
                }
            }
            return  true;
        }
    }

}
